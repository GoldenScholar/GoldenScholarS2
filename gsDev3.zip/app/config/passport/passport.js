//load bcrypt
  var bCrypt = require('bcrypt-nodejs');

  module.exports = function(passport, users, lecture){

  var Users = users;
  var Lecture = lecture;
  var LocalStrategy = require('passport-local').Strategy;


  passport.serializeUser(function(users, done) {
          done(null, users.id);
      });
  
  // used to deserialize the users
  passport.deserializeUser(function(id, done) {
      Users.findById(id).then(function(users) {
        if(users){
          done(null, users.get());
        }
        else{
          done(users.errors,null);
        }
      });

  });

//Users Signup
  passport.use('local-fac-signup', new LocalStrategy(

    {           
      usernameField : 'email',
      passwordField : 'password',
      passReqToCallback : true // allows us to pass back the entire request to the callback
    },

    function(req, email, password, done){
       
	  if(password != req.body.passwordConfirm){return done(null,false);};
      var generateHash = function(password) {
      return bCrypt.hashSync(password, bCrypt.genSaltSync(8), null);
      };

       Users.findOne({where: {email:email}}).then(function(users){

      if(users)
      {
        return done(null, false, {message : 'That email is already taken'} );
      }

      else
      {
        var usersPassword = generateHash(password);
        var data =
        { email:email,
        password:usersPassword,
        username: req.body.username,
		accountType: "faculty"/*,
		score: 0,
		gamesPlayed: 0,
		gamesCreated: 0*/
        };
        Users.create(data).then(function(newUsers,created){
          if(!newUsers){
            return done(null,false);
          }
          if(newUsers){
            return done(null,newUsers); 
          }
        });
      }
    }); 
  }
  ));
//Users registration    
	passport.use('local-stu-signup', new LocalStrategy(

    {           
      usernameField : 'email',
      passwordField : 'password',
      passReqToCallback : true // allows us to pass back the entire request to the callback
    },

    function(req, email, password, done){
       
	  if(password != req.body.passwordConfirm){return done(null,false);};
      var generateHash = function(password) {
      return bCrypt.hashSync(password, bCrypt.genSaltSync(8), null);
      };

      Users.findOne({where: {email:email}}).then(function(users){

      if(users)
      {
        return done(null, false, {message : 'That email is already taken'} );
      }

      else
      {
        var usersPassword = generateHash(password);
        var data =
        { email:email,
        password:usersPassword,
        username: req.body.username,
		accountType: "student"/*,
		score: 0,
		gamesPlayed: 0,
		gamesCreated: 0*/
        };


        Users.create(data).then(function(newUsers,created){
          if(!newUsers){
            return done(null,false);
          }

          if(newUsers){
            return done(null,newUsers);
            
          }


        });
      }


    }); 



  }



  ));
	
	
  //LOCAL Users SIGNIN
  passport.use('local-stu-signin', new LocalStrategy(
    
  {

  // by default, local strategy uses usersname and password, we will override with email
  usernameField : 'email',
  passwordField : 'password',
  passReqToCallback : true // allows us to pass back the entire request to the callback
  },

  function(req, email, password, done) {

    var Users = users;

    var isValidPassword = function(userpass,password){
      return bCrypt.compareSync(password, userpass);
    }

    Users.findOne({ where : { email: email, accountType: "student"}}).then(function (users) {

      if (!users) {
        return done(null, false, { message: 'Email does not exist' });
      }

      if (!isValidPassword(users.password,password)) {

        return done(null, false, { message: 'Incorrect password.' });

      }

      var usersinfo = users.get();

	  console.log("users has logged in");
      return done(null,usersinfo);

    }).catch(function(err){

      console.log("Error:",err);

      return done(null, false, { message: 'Something went wrong with your Signin' });


    });

  }
  ));

  //LOCAL Users SIGNIN
  passport.use('local-fac-signin', new LocalStrategy(
    
  {

  // by default, local strategy uses usersname and password, we will override with email
  usernameField : 'email',
  passwordField : 'password',
  passReqToCallback : true // allows us to pass back the entire request to the callback
  },

  
  function(req, email, password, done) {
    var Users = users;

    var isValidPassword = function(userpass,password){
      return bCrypt.compareSync(password, userpass);
    }

	console.log("point 2 reached");
    Users.findOne({ where : { email: email, accountType: "faculty"}}).then(function (users) {

      if (!users) {
        return done(null, false, { message: 'Email does not exist' });
      }

      if (!isValidPassword(users.password,password)) {

        return done(null, false, { message: 'Incorrect password.' });

      }

      var usersinfo = users.get();

	  console.log("users has logged in");
      return done(null,usersinfo);

    }).catch(function(err){

      console.log("Error:",err);

      return done(null, false, { message: 'Something went wrong with your Signin' });


    });

  }
  ));
  
  //Forgot Password
  passport.use('forgot-pass', new LocalStrategy(

    {           
      usernameField : 'email',
      passwordField : 'password',
      passReqToCallback : true // allows us to pass back the entire request to the callback
    },

    function(req, email, password, done){
       
      var generateHash = function(password) {
      return bCrypt.hashSync(password, bCrypt.genSaltSync(8), null);
      };

       Users.findOne({where: {email:email}}).then(function(users){

      if(!users)
      {
        return done(null, false, {message : 'That email does not exist'} );
      }

      else
      {
        var usersPassword = generateHash(password);
         users.updateAttributes({
         password: usersPassword
         })
		 var usersinfo = users.get();

	  console.log("users has logged in");
      return done(null,usersinfo);
      }
    }); 
  }
  ));
  
}